//
//  BPSampleAppSwiftTests.swift
//  BPSampleAppTests
//
//  Created by Prince S. Valluri on 1/19/18.
//  Copyright © 2018 LinkedIn. All rights reserved.
//

import UIKit
import XCTest

class BPSampleAppSwiftTests: XCTestCase {
    func testZPass() {
        XCTAssert(true)
    }
    
}

